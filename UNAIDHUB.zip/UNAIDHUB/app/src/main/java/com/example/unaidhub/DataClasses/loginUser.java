package com.example.unaidhub.DataClasses;

public class loginUser {

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    String email;

    public loginUser(String email) {
        this.email = email;
    }


}
